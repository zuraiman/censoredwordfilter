<?php
/**
 * Click2Dial Content Plugin
 * 
 * @package		Joomla.Plugin
 * @subpackage	Content.click2dial
 * @since		3.0
 */
defined ( '_JEXEC' ) or die ();

jimport ( 'joomla.plugin.plugin' );

class plgContentCensoredwordfilter extends JPlugin
{
	function plgContentCensoredwordfilter( &$subject, $params )
	{
		parent::__construct ( $subject, $params );
	}

	public function onContentPrepare($context, &$row, &$params, $page = 0)
	{
		// Do not run this plugin when the content is being indexed
		if ($context == 'com_finder.indexer')
		{
			return true;
		}
		
		if (is_object($row))
		{
			return $this->censoredWordfilter($row->text, $params);
		}
		return $this->censoredWordfilter($row, $params);
	}
	
	protected function censoredWordfilter(&$text, &$params)
	{	
		$sensoredwords1 		= $this->params->get('sensoredwords1', "porn,sex");
		$sensoredwords2			= $this->params->get('sensoredwords2', "fuck,shit");
		$phone_icon1disable 	= $this->params->get('phone_icon1disable', "1");
		$phone_icon2disable 	= $this->params->get('phone_icon2disable', "1");
		$phone_icon1			= $this->params->get('phone_icon1', "icon-remove");
		$phone_icon2			= $this->params->get('phone_icon2', "icon-warning");
		$badge_tag1				= $this->params->get('badge_tag1', "badge-important");
		$badge_tag2				= $this->params->get('badge_tag2', "badge-warning");
		$censored_type1			= $this->params->get('censored_type1', "0");
		$censored_type2			= $this->params->get('censored_type2', "1");
		$allow_exceptions		= $this->params->get('allow_exceptions', "1");
		$badge_wordreplacement1 = $this->params->get('badge_wordreplacement1', "CENSORED BY ZUR!");
		$badge_wordreplacement2 = $this->params->get('badge_wordreplacement2', "VULGARITY!");
		$badge_wordreplacement1 = '&nbsp;<span class="badge '.$badge_tag1.'">'.$badge_wordreplacement1.'</span>';
		$badge_wordreplacement2 = '&nbsp;<span class="badge '.$badge_tag2.'">'.$badge_wordreplacement2.'</span>';
		$html_wordreplacement1	= $this->params->get('html_wordreplacement1', "<font color='#ff0000'><b><i>FILTHY WORD!</i></b></font>");
		$html_wordreplacement2	= $this->params->get('html_wordreplacement2', "<s>DIRTY WORD!</s>");
		$icon1path	  			= '&nbsp;<i class="'.$phone_icon1.'"></i>';
		$icon2path	  			= '&nbsp;<i class="'.$phone_icon2.'"></i>';
		$pattern				= '/\s+/';
		$sensoredwords1 		= preg_replace($pattern, '', $sensoredwords1);
		$sensoredwords2 		= preg_replace($pattern, '', $sensoredwords2);
		$sensoredwords1_array 	= explode(',', $sensoredwords1);
		$sensoredwords2_array 	= explode(',', $sensoredwords2);

		if ($allow_exceptions == "1")
		{
			if (JString::strpos($text, '{NoCensor}') !== false)
			{
				$text = str_replace('{NoCensor}', '', $text);
				return true;
			}
		}
	
		if ($phone_icon1disable)
		{
			$badge_wordreplacement1 = $icon1path.$badge_wordreplacement1;
			$html_wordreplacement1	= $icon1path.'&nbsp;'.$html_wordreplacement1;
		}

		if ($phone_icon2disable)
		{
			$badge_wordreplacement2 = $icon2path.$badge_wordreplacement2;
			$html_wordreplacement2	= $icon2path.'&nbsp;'.$html_wordreplacement2;
		}
		
		foreach($sensoredwords1_array as $sensoredword1)
		{
			if ($censored_type1)
			{
				$text = JString::str_ireplace($sensoredword1, $badge_wordreplacement1, $text);
			} else {
				$text = JString::str_ireplace($sensoredword1, $html_wordreplacement1, $text);
			}
		}
		
		foreach($sensoredwords2_array as $sensoredword2)
		{
			if ($censored_type2)
			{
				$text = JString::str_ireplace($sensoredword2, $badge_wordreplacement2, $text);
			} else {
				$text = JString::str_ireplace($sensoredword2, $html_wordreplacement2, $text);
			}
		}

		return true;
	}
}

	